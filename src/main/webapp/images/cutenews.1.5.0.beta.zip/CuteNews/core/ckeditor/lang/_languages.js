﻿/*
Copyright (c) 2003-2011, CKSource - Frederico Knabben. All rights reserved.
For licensing, see LICENSE.html or http://ckeditor.com/license
*/

var CKEDITOR_LANGS=(function(){var b={en:'English'},c=[];for(var d in b)c.push({code:d,name:b[d]});c.sort(function(e,f){return e.name<f.name?-1:1;});return c;})();
